const express = require("express");
const OpenAI = require("openai");

const app = express();
app.use(express.json({ limit: "32kb" }));

const apiKey = process.env.OPENAI_API_KEY;
if (!apiKey) throw new Error("Set OPENAI_API_KEY on the server.");
const openai = new OpenAI({ apiKey });

app.post("/chat", async (req, res) => {
  try {
    const message = String(req.body.message || "").slice(0, 4000);
    if (!message.trim()) return res.status(400).json({ error: "Message required" });
    const response = await openai.responses.create({
      model: "gpt-5-mini",
      input: `You are GPT ASSIST, a friendly gaming strategy coach. Give fair-play advice only; do not help with cheats, bots, or account automation. User message: ${message}`
    });
    res.json({ reply: response.output_text || "I couldn't make a reply." });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Assistant request failed." });
  }
});

app.get("/", (_req, res) => res.send("GPT ASSIST backend is running."));
app.listen(process.env.PORT || 3000, () => console.log("GPT ASSIST backend started"));
