package com.example.gptassist

import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent { AssistantScreen { speak(it) } }
    }
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale("ml", "IN")
    }
    private fun speak(text: String) { tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "gpt-assist") }
    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}

@Composable
fun AssistantScreen(speak: (String) -> Unit) {
    var prompt by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("Hi! I'm GPT ASSIST. Ask me for Free Fire strategy tips.") }
    var busy by remember { mutableStateOf(false) }
    val client = remember { OkHttpClient() }
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("GPT ASSIST", style = MaterialTheme.typography.headlineMedium)
        Text("Your gaming strategy helper")
        Text(answer, modifier = Modifier.weight(1f).fillMaxWidth())
        OutlinedTextField(prompt, { prompt = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Type your question") })
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                if (prompt.isNotBlank() && !busy) {
                    busy = true
                    val question = prompt
                    Thread {
                        try {
                            val body = JSONObject().put("message", question).toString()
                                .toRequestBody("application/json".toMediaType())
                            val request = Request.Builder().url("${ApiConfig.BACKEND_URL}/chat").post(body).build()
                            val response = client.newCall(request).execute()
                            val result = response.body?.string().orEmpty()
                            val text = if (response.isSuccessful) JSONObject(result).optString("reply", "No reply received.")
                                       else "Server error: ${response.code}"
                            runOnUiThread { answer = text; busy = false; speak(text) }
                        } catch (e: Exception) {
                            runOnUiThread { answer = "Can't connect yet. Set up the secure backend URL first."; busy = false }
                        }
                    }.start()
                }
            }, enabled = !busy) { Text(if (busy) "Thinking…" else "Ask") }
            OutlinedButton(onClick = { speak(answer) }) { Text("Speak") }
        }
    }
}
