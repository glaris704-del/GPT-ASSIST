package com.example.gptassist

object ApiConfig {
    // Replace this with your deployed HTTPS backend URL, e.g. https://your-server.example
    const val BACKEND_URL = "https://REPLACE-WITH-YOUR-BACKEND"
}
