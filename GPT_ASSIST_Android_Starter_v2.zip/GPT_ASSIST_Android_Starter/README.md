# GPT ASSIST — Android starter project

This is the **source project**, not an installable APK.

## What it includes
- A simple Android chat screen (Kotlin + Jetpack Compose)
- Voice input using Android speech recognition
- Malayalam text-to-speech replies where the device supports `ml-IN`
- A small Node.js backend that keeps your OpenAI API key off the Android app
- A GitHub Actions workflow that can build a debug APK

## Important
The app is not ready to install until you:
1. Deploy the backend over HTTPS and set `OPENAI_API_KEY` on the server.
2. Put your backend URL in `app/src/main/java/com/example/gptassist/ApiConfig.kt`.
3. Build the Android project with Android Studio or the included GitHub Actions workflow.

Never put your OpenAI API key inside the Android app or share it in chat. API usage may cost money; ask a parent/guardian before setting up billing.

## Build on GitHub (phone-friendly, but setup is still required)
1. Create a GitHub repository and upload the contents of this ZIP.
2. In the repository, open **Actions** and run **Build Android debug APK**.
3. Download the `gpt-assist-debug-apk` artifact from the completed workflow.
4. Android may ask you to allow installation from the browser/files app.

This starter does not yet have a floating overlay over Free Fire or game-control features. It is an in-app assistant only.
